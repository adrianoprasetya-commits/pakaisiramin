SIRAMIN — deployment to Vercel

Files:
- index.html: page structure
- style.css: styling
- script.js: JavaScript behavior

Deploy:
1. Upload this folder to a GitHub repository (keep the three files in the repository root).
2. In Vercel, choose Add New > Project and import the repository.
3. Framework Preset: Other. Build Command: leave empty. Output Directory: . (or leave the default if Vercel detects it).
4. Deploy.

This is a static website; no build step is needed. External font loading requires internet access.
